package cn.qing.demo;

import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.annotation.MapperScans;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import springfox.documentation.oas.annotations.EnableOpenApi;

/**
 * @author: sunQB
 * @date: 2022-01-12 0:37
 * @since: JDK-
 */

@MapperScans(
        @MapperScan(basePackages = {"cn.qing.**.mapper"})
)
@SpringBootApplication
@EnableWebMvc
@EnableOpenApi
public class DemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class,args);
    }
}
