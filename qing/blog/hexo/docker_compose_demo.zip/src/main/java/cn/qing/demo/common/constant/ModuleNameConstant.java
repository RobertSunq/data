package cn.qing.demo.common.constant;

/**
 * 模块名常量
 * @author: sunQB
 * @date: 2022-01-19 0:13
 * @since: JDK-
 */
public interface ModuleNameConstant {

    String DEMO_MODULE= "示例方法";
}
