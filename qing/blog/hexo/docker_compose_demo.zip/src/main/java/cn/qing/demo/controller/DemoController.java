package cn.qing.demo.controller;



import cn.qing.commons.core.response.CommonResult;
import cn.qing.demo.common.constant.ModuleNameConstant;
import cn.qing.demo.service.DemoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author: sunQB
 * @date: 2022-01-12 23:21
 * @since: JDK-1.8
 */


@RestController
@RequestMapping("/demo")
@Api(value = "/demo",tags = ModuleNameConstant.DEMO_MODULE)
public class DemoController {
    Logger logger = LoggerFactory.getLogger(DemoController.class);

    private DemoService demoService;

    private StringRedisTemplate stringRedisTemplate;

    @Value("${server.tomcat.uri-encoding}")
    private String conf;

    @GetMapping("/hello_world")
    @ResponseBody
    @ApiOperation("你好，世界")
    public CommonResult<String> helloWord(){
        logger.info(conf);

        Long views = stringRedisTemplate.opsForValue().increment("views");
        CommonResult<String> commonResult = new CommonResult<>();
        commonResult.setCode(0L);
        commonResult.setData("hello world views : " + ModuleNameConstant.DEMO_MODULE);
        commonResult.setMsg("success");
        return commonResult;
    }

    @Autowired
    public void setDemoService(DemoService demoService) {
        this.demoService = demoService;
    }

    @Autowired
    public void setStringRedisTemplate(StringRedisTemplate stringRedisTemplate) {
        this.stringRedisTemplate = stringRedisTemplate;
    }
}
