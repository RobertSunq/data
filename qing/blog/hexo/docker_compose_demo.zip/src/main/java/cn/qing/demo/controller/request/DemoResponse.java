package cn.qing.demo.controller.request;

/**
 * @author: sunQB
 * @date: 2022-01-16 21:04
 * @since: JDK-
 */
public class DemoResponse {
}
