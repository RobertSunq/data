package cn.qing.demo.entity;

import cn.qing.commons.core.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableField;

import javax.validation.constraints.NotBlank;
import java.time.LocalDateTime;

/**
 * @author: sunQB
 * @date: 2022-01-16 19:58
 * @since: JDK-
 */


public class DemoEntity extends BaseEntity {
    /**
     * 用户姓名
     */
    @NotBlank(message = "用户姓名不能为空")
    @TableField(value = "USER_NAME")
    private String userName;

    /**
     * 用户编码
     */
    @NotBlank(message = "用户编码")
    @TableField(value = "USER_CODE")
    private String userCode;

    /**
     * 联系电话
     */
    @TableField(value = "TELEPHONE")
    private String telephone;

    public DemoEntity() {
    }

    public DemoEntity(Long id, Long sortValue, String sysCreateUser,
                      LocalDateTime sysCreateTime, String sysUpdateUser,
                      LocalDateTime sysUpdateTime, String sysFlag,
                      @NotBlank(message = "用户姓名不能为空") String userName,
                      @NotBlank(message = "用户编码") String userCode, String telephone) {
        super(id, sortValue, sysCreateUser, sysCreateTime, sysUpdateUser, sysUpdateTime, sysFlag);
        this.userName = userName;
        this.userCode = userCode;
        this.telephone = telephone;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }
}
