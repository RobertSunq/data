package cn.qing.demo.mapper;

import org.apache.ibatis.annotations.Mapper;

/**
 * @author: sunQB
 * @date: 2022-01-16 19:51
 * @since: JDK-
 */

@Mapper
public interface DemoMapper{
}
