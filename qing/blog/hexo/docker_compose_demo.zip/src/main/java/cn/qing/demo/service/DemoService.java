package cn.qing.demo.service;

/**
 * @author: sunQB
 * @date: 2022-01-16 19:50
 * @since: JDK-
 */
public interface DemoService {
}
