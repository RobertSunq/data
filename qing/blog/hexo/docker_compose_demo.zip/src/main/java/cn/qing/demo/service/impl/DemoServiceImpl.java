package cn.qing.demo.service.impl;

import cn.qing.demo.service.DemoService;
import org.springframework.stereotype.Service;

/**
 * @author: sunQB
 * @date: 2022-01-16 19:51
 * @since: JDK-
 */

@Service
public class DemoServiceImpl implements DemoService {
}
